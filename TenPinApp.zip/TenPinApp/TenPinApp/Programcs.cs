﻿using System;

namespace TenPinApp
{
    class Programcs
    {
        static public void Main(String[] args)
        {

        }
    }
}
